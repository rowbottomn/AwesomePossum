﻿using UnityEngine;
using System.Collections;

public class MagneticFieldController : MonoBehaviour {

    public float fieldStrength;
    public Vector3 field;
       
    
	// Use this for initialization
	void Start () {
	    
	}

    private void OnTriggerStay(Collider other)
    {
        GameObject p = other.gameObject;
        if (p.CompareTag("Ion"))
        {
            Rigidbody rb = p.GetComponent<Rigidbody>();
            Vector3 magForce = Vector3.Cross(rb.velocity, field);
                        
            rb.AddForce(magForce*Time.fixedDeltaTime);
            print(magForce);
        }
    }

    private void FixedUpdate()
    {
        
    }

    // Update is called once per frame
    void Update () {
	
	}

}
