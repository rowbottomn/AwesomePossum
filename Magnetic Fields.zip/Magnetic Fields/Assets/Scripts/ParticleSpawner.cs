﻿using UnityEngine;
using System.Collections;

public class ParticleSpawner : MonoBehaviour {

    public GameObject electron;
    public GameObject proton;
    public float range;
    public int maxParticles;
    public float maxSpeed;
    public Vector3 preferredDirection;

    ArrayList particles;
    Random rand;
	// Use this for initialization
	void Start () {
        particles = new ArrayList();
        rand = new Random();
	}
	
	// Update is called once per frame
	void Update () {
	    if (particles.Count < maxParticles)
        {
            Vector3 randomPosition = Random.onUnitSphere;
            randomPosition *= range;
            GameObject temp = (GameObject)Instantiate(electron, randomPosition, Quaternion.Euler(0, 0, 0));
            particles.Add(temp);
            Rigidbody rb = temp.GetComponent<Rigidbody>();
            rb.velocity = -maxSpeed * Random.insideUnitSphere;
            rb.velocity.Scale(preferredDirection);
        }

        for (int i = 0; i < particles.Count; i++)
        {
            GameObject tempP = (GameObject)particles[i];
            if (tempP.transform.position.magnitude > 30)
            {
                particles.Remove(tempP);
                Destroy(tempP);
            }
        }
        

    }
}
