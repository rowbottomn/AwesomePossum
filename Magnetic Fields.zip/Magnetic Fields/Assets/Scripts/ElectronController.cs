﻿using UnityEngine;
using System.Collections;

public class ElectronController : MonoBehaviour {
    public float charge;
    public Vector3 vel;
    float mass;
    Rigidbody rb;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
      //  rb.velocity = vel;
	}

    private void FixedUpdate()
    {
        
    }

    // Update is called once per frame
    void Update () {

	}
}
